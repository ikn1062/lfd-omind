#!/usr/bin/env python3
import rospy
from std_msgs.msg import Float64
from geometry_msgs.msg import Twist


def cmd_effort(msg: Twist):
    cmd = Float64()
    cmd = msg.angular.z * 2.0
    """
    cmd = 0.0
    if msg.angular.z == 1.0:  
        cmd = 1.0
    elif msg.angular.z == -1.0:  
        cmd = -1.0
    """ 
    rospy.loginfo(f"Force: {cmd}")
    pub.publish(cmd)


if __name__ == "__main__":
    rospy.init_node("cart_effort_controller")
    
    pub = rospy.Publisher("/cart_pole_controller/command", Float64, queue_size=10)
    sub = rospy.Subscriber("/cmd_vel", Twist, callback=cmd_effort)
    
    rospy.loginfo("Effort Controller Node has been started")
    rospy.spin()