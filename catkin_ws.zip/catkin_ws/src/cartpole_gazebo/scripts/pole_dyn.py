#!/usr/bin/env python3
import rospy
from math import pi
from sensor_msgs.msg import JointState

def pole_state(msg: JointState):
    # rospy.loginfo(msg.name[0])
    theta = msg.position[0]
    
    while theta < -2 * pi:
        theta += 2 * pi
    while theta > 2 * pi:
        theta -= 2 * pi
    
    theta_dot = msg.velocity[0]
    rospy.loginfo(f"(t: {theta}, td: {theta_dot})")


if __name__ == "__main__":
    rospy.init_node("pole_state_sub")
    sub = rospy.Subscriber("/cart_pole/joint_states", JointState, callback=pole_state)    
    
    rospy.loginfo("Pole State Node has been started")
    
    rospy.spin()
